import { LightningElement, track } from 'lwc';
import sendRequestToOllama from "@salesforce/apex/OllamaAPIHandler.sendRequestToOllama";

export default class AiChatPromptOllamaLwc extends LightningElement {
    @track _waiting = false;
    @track _promptData = { "input": "", result: "" };
    @track _showResult = false;
    handleChange(event) {
        if (event.target.name == 'prompt') {
            this._promptData.input = event.target.value;
        }
        console.log('this._promptData.input --> ' + this._promptData.input);
    }
    
    handleSearch(event) {
        if (this._promptData.input == "") {
            this.template.querySelector("c-custom-toast-lwc").showToast("error", 'Propmt is empty,Please search valid');
        } else {
            this._waiting = true;
            sendRequestToOllama({ message: this._promptData.input }).then((result) => {
                this._waiting = false;
                if (result) {
                    this._promptData.result = result;
                    this._showResult = true;
                    console.log('result --> ' + result);
                }
            }).catch(error => {
                console.log('24 ' + JSON.stringify(error));
                this._waiting = false;
                let message =
                    "An error has occured. That is all we know right now.";

                message = error.body.message;
                if (message.detail) {
                    this.template
                        .querySelector("c-custom-toast-lwc")
                        .showToast("error", `${message.detail}`);
                } else {
                    this.template
                        .querySelector("c-custom-toast-lwc")
                        .showToast("error", `${message}`);
                }

            })

        }

    }
}